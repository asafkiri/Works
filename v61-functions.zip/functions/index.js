/* ============================================================
   תזכורות החתמה (v61) — פונקציית ענן
   ------------------------------------------------------------
   רצה כל דקה. שולחת פוש לעובד בדיוק בשעת הכניסה/היציאה שבסידור:
   - כניסה: אם עדיין אין לו משמרת פתוחה.
   - יציאה: אם המשמרת עדיין פתוחה.
   מכבדת "ביצעתי" (done) וסנוז (snoozeUntil) שהעובד בוחר באפליקציה.
   התעלמות: תזכורת חוזרת כל RESEND_MIN דקות, עד MAX_SENDS פעמים.
   ============================================================ */
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { setGlobalOptions } = require("firebase-functions/v2");
const admin = require("firebase-admin");

admin.initializeApp();
setGlobalOptions({ region: "europe-west1", maxInstances: 1 });

const TZ = "Asia/Jerusalem";
// ⬇️ כתובת האפליקציה כפי שהעובדים פותחים אותה. לעדכן אם עוברים לדומיין אחר.
const APP_URL = "https://asafkiri.github.io/Works/";
const RESEND_MIN = 20; // דקות בין תזכורות למי שהתעלם
const MAX_SENDS = 3;   // מקסימום שליחות רצופות ללא תגובה (סנוז מאפס את המונה)

/* השעה המקומית בישראל: תאריך ISO, דקות מתחילת היום, ויום בשבוע (0=ראשון) */
function nowInTz() {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hour12: false, weekday: "short",
  });
  const parts = {};
  fmt.formatToParts(new Date()).forEach((p) => { parts[p.type] = p.value; });
  let hour = parseInt(parts.hour, 10); if (hour === 24) hour = 0;
  const dowMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return {
    iso: `${parts.year}-${parts.month}-${parts.day}`,
    minutes: hour * 60 + parseInt(parts.minute, 10),
    dow: dowMap[parts.weekday],
  };
}

const toMin = (s) => {
  const p = String(s || "0:0").split(":");
  return (parseInt(p[0], 10) || 0) * 60 + (parseInt(p[1], 10) || 0);
};
const slotOf = (kind, time) => kind + "-" + String(time || "").replace(":", "");

exports.clockReminders = onSchedule(
  { schedule: "* * * * *", timeZone: TZ, retryCount: 0 },
  async () => {
    const db = admin.database();
    const t = nowInTz();
    const now = Date.now();

    const [empSnap, recSnap, oneSnap, tokSnap, remSnap] = await Promise.all([
      db.ref("employees").get(),
      db.ref("recurringShifts").get(),
      db.ref("oneTimeShifts").get(),
      db.ref("pushTokens").get(),
      db.ref("reminders").get(),
    ]);
    const employees = empSnap.val() || {};
    const recurring = recSnap.val() || {};
    const oneTime = oneSnap.val() || {};
    const tokens = tokSnap.val() || {};
    const reminders = remSnap.val() || {};

    /* משמרת פתוחה = openShiftId על העובד + אימות שאין clockOut */
    const openIds = Object.keys(employees).filter(
      (id) => employees[id] && employees[id].openShiftId
    );
    const openChecks = await Promise.all(
      openIds.map((id) =>
        db.ref("shifts/" + employees[id].openShiftId).get()
          .then((s) => {
            const sh = s.val();
            return [id, !!(sh && sh.clockIn && !sh.clockOut)];
          })
          // קריאה נכשלה? מניחים שפתוחה — עדיף תזכורת מיותרת מהחמצה
          .catch(() => [id, true])
      )
    );
    const hasOpen = {};
    openChecks.forEach(([id, open]) => { hasOpen[id] = open; });

    /* המשמרות המתוכננות של היום (קבועות שלא בוטלו + חד-פעמיות) */
    const occs = [];
    Object.values(recurring).forEach((r) => {
      if (!r || !Array.isArray(r.daysOfWeek) || !r.daysOfWeek.includes(t.dow)) return;
      if (r.cancelledDates && r.cancelledDates[t.iso]) return;
      const e = employees[r.employeeId];
      if (!e || e.active === false) return;
      occs.push({ empId: r.employeeId, name: e.name || "", start: r.startTime, end: r.endTime });
    });
    Object.values(oneTime).forEach((o) => {
      if (!o || o.date !== t.iso) return;
      const e = employees[o.employeeId];
      if (!e || e.active === false) return;
      occs.push({ empId: o.employeeId, name: e.name || "", start: o.startTime, end: o.endTime });
    });

    const updates = {};
    const sends = [];

    for (const occ of occs) {
      const empTok = tokens[occ.empId]
        ? Object.entries(tokens[occ.empId]).filter(([, v]) => v && v.token)
        : [];
      if (empTok.length === 0) continue; // העובד לא הפעיל תזכורות — אין למי לשלוח

      const startMin = toMin(occ.start);
      const endMin = toMin(occ.end);
      const open = !!hasOpen[occ.empId];

      for (const kind of ["in", "out"]) {
        const target = kind === "in" ? startMin : endMin;
        const time = kind === "in" ? occ.start : occ.end;
        const slot = slotOf(kind, time);
        const st = ((reminders[occ.empId] || {})[t.iso] || {})[slot] || {};
        const base = "reminders/" + occ.empId + "/" + t.iso + "/" + slot;

        if (st.done) continue;

        /* רלוונטיות + סגירה שקטה כשהמערכת רואה שההחתמה בוצעה */
        let relevant;
        if (kind === "in") {
          if (open && st.lastSentAt) { updates[base + "/done"] = true; continue; }
          // תזכורת כניסה חיה משעת ההתחלה ועד סוף המשמרת (או ללא הגבלה במשמרת חוצת-חצות)
          relevant = !open && t.minutes >= target && (endMin <= startMin || t.minutes < endMin);
        } else {
          if (!open && st.lastSentAt) { updates[base + "/done"] = true; continue; }
          relevant = open && t.minutes >= target;
        }
        if (!relevant) continue;

        if (st.snoozeUntil && now < st.snoozeUntil) continue; // סנוז פעיל

        const count = st.sentCount || 0;
        let shouldSend = false;
        if (!st.lastSentAt) shouldSend = true;                                   // שליחה ראשונה
        else if (st.snoozeUntil && now >= st.snoozeUntil) shouldSend = true;     // הסנוז נגמר
        else if (now - st.lastSentAt >= RESEND_MIN * 60000 && count < MAX_SENDS) // התעלמות
          shouldSend = true;
        if (!shouldSend) continue;

        updates[base + "/sentCount"] = count + 1;
        updates[base + "/lastSentAt"] = now;
        updates[base + "/snoozeUntil"] = null;

        const title = kind === "in" ? "🔔 המשמרת שלך מתחילה" : "🕔 סוף משמרת — החתמת יציאה?";
        const body = kind === "in"
          ? `${occ.name}, המשמרת שלך מתחילה ב-${time}. אם עוד לא החתמת כניסה — הטרמינל מחכה 🙂`
          : `${occ.name}, המשמרת שלך מסתיימת ב-${time}. תחתים יציאה בטרמינל בדרך החוצה 👋`;
        const link = `${APP_URL}?reminder=${kind}&slot=${slot}&date=${t.iso}&time=${encodeURIComponent(time)}`;

        for (const [tokKey, tokVal] of empTok) {
          sends.push({
            empId: occ.empId, tokKey,
            msg: {
              token: tokVal.token,
              notification: { title, body },
              data: { kind, slot, date: t.iso, time: String(time || "") },
              webpush: {
                headers: { Urgency: "high", TTL: "1800" },
                notification: {
                  title, body, dir: "rtl", lang: "he",
                  icon: APP_URL + "icon-192.png",
                  tag: slot + "-" + t.iso, // תזכורת חוזרת מחליפה את הקודמת, לא נערמת
                  renotify: true,
                },
                fcmOptions: { link },
              },
            },
          });
        }
      }
    }

    /* שליחה + ניקוי token-ים שכבר לא בתוקף (עובד שהסיר הרשאה/החליף מכשיר) */
    await Promise.all(
      sends.map((s) =>
        admin.messaging().send(s.msg).catch((err) => {
          const code = String((err && (err.code || (err.errorInfo && err.errorInfo.code))) || "");
          if (code.includes("registration-token-not-registered") || code.includes("invalid-argument")) {
            updates["pushTokens/" + s.empId + "/" + s.tokKey] = null;
          }
        })
      )
    );

    /* ניקיון: מוחקים מצבי תזכורת בני יומיים ומעלה */
    Object.keys(reminders).forEach((empId) => {
      Object.keys(reminders[empId] || {}).forEach((dateIso) => {
        const dt = new Date(dateIso + "T00:00:00Z").getTime();
        if (isFinite(dt) && now - dt > 2 * 24 * 3600 * 1000) {
          updates["reminders/" + empId + "/" + dateIso] = null;
        }
      });
    });

    if (Object.keys(updates).length) await db.ref().update(updates);
  }
);
